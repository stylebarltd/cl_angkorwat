cl_logo2 - cubeLadder logo
Map model for cl_angkorwat by cubeladder.
License: CC BY-SA 4.0 (https://creativecommons.org/licenses/by-sa/4.0/)
Source: https://github.com/stylebarltd/cl_angkorwat
