galroof_14x12_h6 - Khmer gallery roof 14x12
Map model for cl_angkorwat by cubeladder.
License: CC BY-SA 4.0 (https://creativecommons.org/licenses/by-sa/4.0/)
Source: https://github.com/stylebarltd/cl_angkorwat
