vault_24x14_h6_b2.0_v0 - Khmer vault roof 24x14
Map model for cl_angkorwat by cubeladder.
License: CC BY-SA 4.0 (https://creativecommons.org/licenses/by-sa/4.0/)
Source: https://github.com/stylebarltd/cl_angkorwat
