vines_16_0s - Hanging vines
Map model for cl_angkorwat by cubeladder.
License: CC BY-SA 4.0 (https://creativecommons.org/licenses/by-sa/4.0/)
Source: https://github.com/stylebarltd/cl_angkorwat
